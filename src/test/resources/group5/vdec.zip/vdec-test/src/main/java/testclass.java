/**
 * Testklasse ohne undefinierte Variablen
 */
public class testclass {

    private int zahlclass;
    private String wordclass;

    public testclass(String word, int zahlclass)
    {
        this.zahlclass = zahlclass;
        this.wordclass = word;
    }


    public void setzahlclass(int zahl)
    {
        this.zahlclass= zahl;
    }

    public void setWordclass(String word)
    {
        wordclass =word;
    }
    public int rechner(int zahl, int zahl2)
    {
        int localzahl = zahl + zahl2;
        localzahl = localzahl + zahlclass;
        return localzahl;
    }

    public String welcome(String word)
    {
        String back = wordclass;
        back = back + ","+ word;
        return back;
    }


}
