public class testclass {

    private int zahl;
    private String word;
    private float varfloat;
    private  String end;
    private  String startnull;

    public testclass(int zahl, String word, float varfloat, String end)
    {
        this.zahl = zahl;
        this.word = word;
        this.varfloat =varfloat;
        this.end = end;
        this.startnull = null;
    }

    public int rechner(int zahl, int zahl2)
    {
        int local = zahl +zahl2;
        String localstring =null;
        int local2 =0;
        local2 =local;
        local2= local +this.zahl;


        return local2;
    }
}
