public class vrefmain {
    public static void main(String[] args) {

        testclass test = new testclass(5,"Hi",6,"Bye");
        System.out.println(test.rechner(7,9));
        testclass nullclass = null;
        testnothis nothis = new testnothis();
        nothis.bild(5, "Weg");
    }
}
