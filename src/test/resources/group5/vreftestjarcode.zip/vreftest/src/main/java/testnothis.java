public class testnothis {

    public void bild(int zahl, String word)
    {
        System.out.println("Das Wort des Tages:"+ word + "und zahl des tages:"+zahl);
    }
}
