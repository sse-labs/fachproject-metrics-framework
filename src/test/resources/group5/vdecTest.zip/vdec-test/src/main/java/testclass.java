/**
 * Testklasse ohne undefinierte Variablen
 */
public class testclass {

    private int zahlclass;
    private String wordclass;
    private  int zahlclass2;

    public testclass(String word, int zahlclass)
    {
        this.zahlclass = zahlclass;
        this.wordclass = word;
        this.zahlclass2 = zahlclass;
    }


    public void setzahlclass(int zahl)
    {
        this.zahlclass= zahl;
    }

    public void setWordclass(String word)
    {
        wordclass =word;
    }
    public int rechner(int zahl, int zahl2)
    {
        int localzahl = zahl + zahl2;
        localzahl = localzahl + zahlclass;
        return localzahl;
    }

    public String welcome(String word)
    {
        String back = wordclass;
        back = back + ","+ word;
        return back;
    }

    public int rechner2(int zahl, int zahl2)
    {
        int undeflocal;
        int localzahl = zahl + zahl2;
        localzahl = localzahl + zahlclass;
        zahlclass = localzahl;
        localzahl = zahlclass+ zahl2;
        int local =zahlclass2+zahl;
        localzahl = zahlclass+ zahlclass2;
        return localzahl;
    }
}
