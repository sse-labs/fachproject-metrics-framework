/**
 * Testklasse ohne undefinierte Variablen
 */
public class testclassUndev {

    private int zahlclass;
    private int zahlclass2;
    private String wordclass;
    private  int undefZahl;
    private String undefWord;

    public testclassUndev(String word, int zahlclass)
    {
        this.zahlclass = zahlclass;
        this.zahlclass2 = zahlclass;
        this.wordclass = word;
        this.undefWord = "Bye";
    }


    public void setzahlclass(int zahl)
    {
        this.zahlclass= zahl;
    }

    public void setWordclass(String word)
    {
        wordclass =word;
    }
    public int rechner(int zahl, int zahl2)
    {
        int undeflocal;
        int localzahl = zahl + zahl2;
        localzahl = localzahl + zahlclass;
        return localzahl;
    }

    public String welcome(String word)
    {
        String undeflocal = "Bye";
        String back = wordclass;
        back = back + ","+ word;
        return back;
    }

    public int rechner2(int zahl, int zahl2)
    {
        int undeflocal;
        int localzahl = zahl + zahl2;
        localzahl = localzahl + zahlclass;
        zahlclass = localzahl;
        localzahl = zahlclass+ zahl2;
        int local =zahlclass2+zahl;
        localzahl = zahlclass+ zahlclass2;
        return localzahl;
    }


}
