public class testvdec {

    public static void main(String[] args) {
        testclass class1 = new testclass("Hallo", 7);
        System.out.println(class1.rechner(4,7));
        class1.setzahlclass(6);
        System.out.println(class1.rechner(4,7));
        System.out.println(class1.welcome("Hi"));
        class1.setWordclass("Tag");
        System.out.println(class1.welcome("Hi"));
        testclassUndev class2 = new testclassUndev("Hallo",7);
        System.out.println("Hier Klasse 2:\n");
        System.out.println(class2.rechner(4,7));
        class2.setzahlclass(9);
        System.out.println(class2.rechner(4,7));
        System.out.println(class2.welcome("Hi"));
        class2.setWordclass("Tag");
        System.out.println(class2.welcome("Hi"));
    }
}
