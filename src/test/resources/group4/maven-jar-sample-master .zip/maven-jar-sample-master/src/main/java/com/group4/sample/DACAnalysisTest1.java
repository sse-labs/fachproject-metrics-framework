package com.group4.sample;

public class DACAnalysisTest1 {
	LOCphyAnalysisTest object1 = new LOCphyAnalysisTest();
	RFCAnalysisTest1 object2 = new RFCAnalysisTest1();
	RFCAnalysisTest2 object3,obeject4 = new RFCAnalysisTest2();
	String object5= "...";
 }
