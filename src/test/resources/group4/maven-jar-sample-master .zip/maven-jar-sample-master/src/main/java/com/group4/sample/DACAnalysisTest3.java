package com.group4.sample;

public class DACAnalysisTest3 {
	public boolean b = true;
	public char c;
	public static byte by;
	private short s;
	private int i;
	private static long l;
	float f;
	double d;
	public static LOCphyAnalysisTest object1 = new LOCphyAnalysisTest();
	RFCAnalysisTest1 object2 = new RFCAnalysisTest1();
	private RFCAnalysisTest2 object3,obeject4 = new RFCAnalysisTest2();
	String object5= "...";
}
