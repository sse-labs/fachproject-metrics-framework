package com.group4.sample;

public class DACAnalysisTest2 {
	public boolean b = true;
	public char c ;
	public static byte by;
	private short s;
	private int i;
	private static long l;
	float f;
	double d;
}
