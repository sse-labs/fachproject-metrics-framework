# maven-jar-sample
A simple Java project for testing purposes
